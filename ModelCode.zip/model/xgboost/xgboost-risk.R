#Title:'xgboost model'
#Author:'yunbin.jiang', EnglishName:Joey.
#Date: '18 April 2017'

library(xgboost)
setwd('file')
# read data
train=read.csv('train_x.csv')
test=read.csv('test_x.csv')
train.y=train[,"traget"]
cols <- unlist(lapply(train, class))
unique(cols)
fn.cat=names(cols[cols=="factor"])
fn.num=names(cols[cols=="numeric"])


#missing data handle
options(scipen = 20)
for (i in 1:ncol(train)) {
  if (class(train[, i]) == "numeric") {
    train[, i][is.na(train[, i])] <- -1
  } else {
    train[, i][is.na(train[, i])] <- "UNKOWN"
    
  }
}


# create dummy variables
temp.train=data.frame(rep(0,nrow(train)))
temp.test=data.frame(rep(0,nrow(test)))
for(f in fn.cat){
  levels=unique(train[,f])
  col.train=data.frame(factor(train[,f],levels=levels))
  col.test=data.frame(factor(test[,f],levels=levels))
  colnames(col.train)=f
  colnames(col.test)=f
  temp.train=cbind(temp.train,model.matrix(as.formula(paste0('~',f,'-1')),data=col.train))
  temp.train[,paste0(f,'-1')]=NULL
  temp.test=cbind(temp.test,model.matrix(as.formula(paste0('~',f,'-1')),data=col.test))
  temp.test[,paste0(f,'-1')]=NULL
}
temp.train[,1]=NULL
temp.test[,1]=NULL
train.new=as.matrix(data.matrix(cbind(train[,c('uid',fn.num)],temp.train)),sparse=T)
test.new=as.matrix(data.matrix(cbind(test[,c('uid',fn.num)],temp.test)),sparse=T)


# fit xgboost model

dtrain=xgb.DMatrix(data=train.new[,-1],label=1-train.y)
dtest= xgb.DMatrix(data=test.new[,-1])

model=xgb.train(booster='gbtree',
                objective='binary:logistic',
                scale_pos_weight=8.7,
                gamma=0,
                lambda=700,
                subsample=0.7,
                colsample_bytree=0.30,
                min_child_weight=5,
                max_depth=8,
                eta=0.02,
                data=dtrain,
                nrounds=1520,
                metrics='auc',
                nthread=8)

# predict probabilities
pred=1-predict(model,dtest)
#average error
err <-mean(as.numeric(pred >0.5) != test$target)
print(paste("test-error=", err))

#View feature importance/influence fromthe learnt model
importance_matrix <- xgb.importance(model = model)
print(importance_matrix)
xgb.plot.importance(importance_matrix = importance_matrix)     
      
      
write.csv(data.frame('uid'=test.new[,1],'score'=pred),file='file/R_name.csv',row.names=F)