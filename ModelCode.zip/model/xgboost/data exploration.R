#Title:'xgboost model'
#Author:'yunbin.jiang', EnglishName:Joey.
#Date: '18 April 2017'

#load packages
library(Hmisc)
library(timeDate)
library(fBasics)
library(ggplot2)
library(corrplot)
library(e1071)
# Data exploration
train <- load("")
test <- load("")
# other way to read data
setwd('file')
train=read.csv('train_x.csv')
test=read.csv('test_x.csv')

dim(trian) #view train dimension
dim(test) #view test dimension

head(iris)  # head 5 row data
tail(iris)  # tail 5 row data

summary(train)  #data summary
summary(test)  #data summary

#data describe , you can get variables infos
#as follows: very variable Contains x values, x missing values, x unique values,
            #mean, each major quartile, minimum and  max 
describe(train)  #data describe
describe(test)   #data describe


train <- iris[1:4]
#Descriptive statistics
temp.train=matrix(0,nrow =ncol(train), ncol=10)
colnames(temp.train)[1:10] <- c("sum","mean","median","max","min","range","variance","std","skewness","kurtosis")

for (i in 1:ncol(train)){
x1 <- sum(train[,i])  #sum
x2 <- mean(train[,i])  #mean
x3 <- median(train[,i])  #median
x4 <- max(train[,i])  #max
x5 <- min(train[,i])  #min
x6 <- max(train[,i])-min(train[,i])  #xmax-xmin
x7 <- var(train[,i])  #variance  
x8 <- sd(train[,i])  #std
x9 <- skewness(train[,i])  #skewness
x10 <- kurtosis(train[,i])  #kurtosis 
temp.train[i,] <- cbind(x1,x2,x3,x4,x5,x6,x7,x8,x9,x10)

}

write.csv(temp.train, file = "file/describe.csv",sep = ",",row.names =TRUE,fileEncoding ="UTF-8")

#Commonly used statistics
#the number of observations,NAs,mean error,
#the upper and lower limits of the mean at 95% confidence level,Variance and Std
basicStats(train)  
basicStats(test) 

cor(train)   #correlation coefficient matrix
sum(complete.cases(train))  #The number of complete records
sum(is.na(train))  #The number of missing values
unique(train$variable)  #unique value
table(train$variable)   #frequency


# data visualization and describe the distribution
plot(train$variable, train$y) # continuous variable ,if need to translate
pairs(train)     #Matrix scatter plot ,don't like use it
hist(train$variable,breaks=seq(4,8,0.2))  #hist plot
hist(train$variable,freq = F)
lines(density(train$variable))  

# to find the outliers
par(mfrow=c(2,2)) #
boxplot(train$variable, main="单变量箱线图")    # one
boxplot(train$variable1,train$variable2,main="双变量箱线图") #two
boxplot(train, main="多变量箱线图")    # more 
boxplot(train$variable~target,horizontal=T)   #
detach(train) 

#Correlation coefficient matrix
(cor <- cor(train)) 
par(mfrow=c(1,2))
corrplot(cor) 
#The darker the ellipse, the deeper the color, the higher the correlation coefficient
corrplot(cor,method = "ellipse")     


####

par(mfrow = c(1,2))
plot(density(train$variable1),main = "The normal distribution curve of the variable1") # 
plot(density(train$variable2),main = "The normal distribution curve of the variable2") # 
par(mfrow = c(1,1))


par(mfrow = c(1,2))
plot(density(log(train$variable1)),main = "The normal distribution curve of the logarithm variable1 ") 
plot(density(log(train$variable2)),main = "The normal distribution curve of the logarithm variable2 ") 
par(mfrow = c(1,1))


# establish a linear regression model
fit1 <- lm(train$variable~train$traget,data = dsmall) # Modeling the original variable
summary(fit1) # View the model details
fit2 <-lm(log(train$variabl)~log(train$traget),data=dsmall) # log the number after modeling
summary(fit2) # View the model details



# Draw the fit curve in the scatter plot
par(mfrow=c(1,2))
plot(train$variable,train$traget, main = "Untreated scatter plot and fit straight line")
abline(fit1,col="red",lwd=2)
plot(log(train$variabl),log(train$traget), main = "Take the scatter plot after the logarithm and fit the straight line")
abline(fit2,col="red",lwd=2)
par(mfrow=c(1,1))


