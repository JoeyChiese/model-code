#title:'xgboost model'
#author:'yunbin.jiang', EnglishName:Joey.
#date: '18 April 2017'

#Data preprocessing
#1 standardization
scale(train, center = TRUE, scale = TRUE)

# Centralization
library(BBmisc)
normalize(train)

#2 Range reduction method
maxmin <- function(col) {
  maxmin <- (col - min(col))/(max(col) - min(col))
  return(maxmin)}
maxmin(iris.data)

#3 Normalized
norm <- function(data) {
  norm = apply(data, 1, function(x) {
    x/sqrt(sum(x^2))
  })
  norm = t(norm)
  return(norm)}

#4 Quantitative feature binarization 0,1
#threshold is the Threshold
bina <- function(data, threshold) {
  ifelse(data > threshold, 1, 0)}

#Qualitative feature dumb coding
library(caret)
var <- dummyVars(~Species, data = train)
predict(var, train["target"])

#Missing value padding
new = rep(NA, 4)
temp.data <- rbind(new, train)
library(Hmisc)
impute(temp.data,fun= mean)

#Data transformation
library(dplyr)
temp.data <- train %>% 
  mutate(x3 = variable1 * variable12)
temp.data <- temp.data %>% 
  mutate_each(funs(log1p))