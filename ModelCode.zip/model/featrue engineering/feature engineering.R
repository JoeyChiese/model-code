#------------------------------ original variables preprocessing------------------------
#Title:feature engineering  
#Author:yunbin.jiang, EnglishName:joey
#Import:dplyr,parallel
#Date:'18 April 2017'


# missing data handle
Is_null <- function(x) {
  if(is.na(x)) {
    return(1)
  }
  else {
    return(0)
  }
}

#Gender classification 
sex_classify <- function(x) {
  if(!is.na(x)) {
    if(grepl("男", x)) {
      return("male")
    }
    if(grepl("女", x)) {
      return("feamle")
    }
    else {
      return('null')
    }
  }
  else {
    return('null')
  }
}


#Academic grade classification
degree_classify <- function(x) {
  if(!is.na(x)) {
    if(grepl("硕士|博士", x)) {
      return('postgraduate')
    }
    if(grepl("大学", x)) {
      return('undergraduate ')
    }
    if(grepl("专", x)) {
      return('middleDegree')
    }
    else {
      return('lowDegree')
    }
  }
  else {
    return('null')
  }
}


#Mobile phoneNumber 
telephone_classify <- function(x) {
  if(!is.na(x)) {
    if(grepl("^1(3|4|5|7|8)", x)) {
      x = substr(x, 1, 3)
      return(x)
    }
    else {
      return(-999)
    }
  }
  else {
    return('null')
  }
}


#Email classification
email_classify <- function(x) {
  if(!is.na(x) & grepl("@", x)) {
    suffix = unlist(strsplit(x, '@'))
    suffix = tolower(suffix[2])
    if(suffix == 'qq.com') {
      return("qq")
    }
    if(suffix == '163.com' || suffix == '126.com') {
      return("WangYi")
    }
    else {
      return('others')
    }
  }
  else {
    return('null')
  }
}


#City classification 
city_classify <- function(x) {
  if(!is.na(x)) {
    if(grepl("北京|上海|深圳|广州", x)) {
      return('BigCity')
    }
    if(grepl("武汉|杭州|天津|南京|无锡|成都|重庆", x)) {
      return('MiddleCity')
    }
    else {
      return('SmallCity')
    }
  }
  else {
    return('null')
  }
}

#Social security payment status classification
X_status_classify <- function(x) {
  if(!is.na(x)) {
    if(grepl("正常|参保缴费|投保|在职|有效|在业", x)) {
      return("normal")
    }
    if(grepl("中断|停保|未参保|离职|统筹冻结", x)) {
      return("suspend")
    }
    else {
      return("others")
    }
  }
  else {
    return("null")
  }
}

#Nation classfication
nation_classify <- function(x) {
  if(!is.na(x)) {
    if(x == '汉族') {
      return('Han')
    }
    else {
      return('others')
    }
  }
  else {
    return('null')
  }
}

#Marital status classificaton
marital_status_classify <- function(x) {
  if(!is.na(x)) {
    if(x == '已婚') {
      return('married')
    }
    if(x == '未婚' || x == '离婚') {
      return('unmarried')
    }
    else {
      return('others')
    }
  }
  else {
    return('null')
  }
}

# Income processing
money_processed <- function(x) {
  if(!is.na(x)) {
    x = sub('元$', '', x)
    return(as.numeric(x))
  }
  else {
    return(999)
  }
}


# to numeric
char_to_numeric <- function(x) {
  if(!is.na(x)) {
    return(as.numeric(x))
  }
  else {
    return(999)
  }
}



#----------------------------------XDetail_Features----------------------------
X_detail_features_func <- function(data) {
  mc <- 1
  library(dplyr)
  library(parallel)
  data <- data %>%
    mutate(
      month_rmb = ifelse(month_rmb == 'NA', NA, as.numeric(month_rmb)),
      balance_rmb = ifelse(balance_rmb == 'NA', NA, as.numeric(balance_rmb)),
      base_rmb = ifelse(base_rmb == 'NA', NA, as.numeric(base_rmb)),
      com_rmb = ifelse(com_rmb == 'NA', NA, as.numeric(com_rmb)),
      per_rmb = ifelse(per_rmb == 'NA', NA, as.numeric(per_rmb))
    ) %>%
    as.data.frame()
  data$start_date <- unlist(mclapply(data$start_date, date_processed, mc.cores = mc))
  data[data[, ] == 'NA'] <- NA
  
  X_detail_features <- data %>%
    group_by(appl_no) %>%
    mutate(
      start_date = as.Date(start_date),
      base_rmb = abs(base_rmb),
      com_rmb = abs(com_rmb),
      per_rmb = abs(per_rmb),
      month_rmb = abs(month_rmb),
      month_Intervals = round(as.numeric(difftime(as.Date(appl_sbm_tm), start_date, units = 'days')) / 30, 0)
    ) %>%
    summarise(
      #custorm_id = custorm_id[1],
      payment_nums = n(),
      flowtype_counts = n_distinct(flow_type),
      month_Intervals_min = min(month_Intervals),
      month_Intervals_max = max(month_Intervals),
      month_Intervals_median = median(month_Intervals),
      month_Intervals_mean = mean(month_Intervals),
      month_Intervals_std = sd(month_Intervals),
      
      current_balance_rmb = balance_rmb[month_Intervals == month_Intervals_min][1],
      current_com_rmb = com_rmb[month_Intervals == month_Intervals_min][1],
      current_per_rmb = per_rmb[month_Intervals == month_Intervals_min][1],
      current_month_rmb = month_rmb[month_Intervals == month_Intervals_min][1],
      
      payment_nums_sixMonth = sum(month_Intervals <= 6),
      payment_nums_oneYear = sum(month_Intervals <= 12),
      payment_nums_twoYear = sum(month_Intervals <= 24),
      
      payment_nums_type1 = sum(flow_type == '1'),
      payment_nums_type1_sixMonth = sum(flow_type == '1' & month_Intervals <= 6),
      payment_nums_type1_oneYear = sum(flow_type == '1' & month_Intervals <= 12),
      payment_nums_type1_twoYear = sum(flow_type == '1' & month_Intervals <= 24),
      payment_nums_type2 = sum(flow_type == '2'),
      payment_nums_type2_sixMonth = sum(flow_type == '2' & month_Intervals <= 6),
      payment_nums_type2_oneYear = sum(flow_type == '2' & month_Intervals <= 12),
      payment_nums_type2_twoYear = sum(flow_type == '2' & month_Intervals <= 24),
      payment_nums_type3 = sum(flow_type == '3'),
      payment_nums_type3_sixMonth = sum(flow_type == '3' & month_Intervals <= 6),
      payment_nums_type3_oneYear = sum(flow_type == '3' & month_Intervals <= 12),
      payment_nums_type3_twoYear = sum(flow_type == '3' & month_Intervals <= 24),
      payment_nums_type4 = sum(flow_type == '4'),
      payment_nums_type4_sixMonth = sum(flow_type == '4' & month_Intervals <= 6),
      payment_nums_type4_oneYear = sum(flow_type == '4' & month_Intervals <= 12),
      payment_nums_type4_twoYear = sum(flow_type == '4' & month_Intervals <= 24),
      payment_nums_type5 = sum(flow_type == '5'),
      payment_nums_type5_sixMonth = sum(flow_type == '5' & month_Intervals <= 6),
      payment_nums_type5_oneYear = sum(flow_type == '5' & month_Intervals <= 12),
      payment_nums_type5_twoYear = sum(flow_type == '5' & month_Intervals <= 24),
      
      base_rmb_type1_median = median(base_rmb[flow_type == '1']),
      base_rmb_type1_median_sixMonth = median(base_rmb[month_Intervals <= 6 & flow_type == '1']),
      base_rmb_type1_median_oneYear = median(base_rmb[month_Intervals <= 12 & flow_type == '1']),
      base_rmb_type1_median_twoYear = median(base_rmb[month_Intervals <= 24 & flow_type == '1']),
      
      base_rmb_type2_median = median(base_rmb[flow_type == '2']),
      base_rmb_type2_median_sixMonth = median(base_rmb[month_Intervals <= 6 & flow_type == '2']),
      base_rmb_type2_median_oneYear = median(base_rmb[month_Intervals <= 12 & flow_type == '2']),
      base_rmb_type2_median_twoYear = median(base_rmb[month_Intervals <= 24 & flow_type == '2']),
      
      base_rmb_type3_median = median(base_rmb[flow_type == '3']),
      base_rmb_type3_median_sixMonth = median(base_rmb[month_Intervals <= 6 & flow_type == '3']),
      base_rmb_type3_median_oneYear = median(base_rmb[month_Intervals <= 12 & flow_type == '3']),
      base_rmb_type3_median_twoYear = median(base_rmb[month_Intervals <= 24 & flow_type == '3']),
      
      base_rmb_type4_median = median(base_rmb[flow_type == '4']),
      base_rmb_type4_median_sixMonth = median(base_rmb[month_Intervals <= 6 & flow_type == '4']),
      base_rmb_type4_median_oneYear = median(base_rmb[month_Intervals <= 12 & flow_type == '4']),
      base_rmb_type4_median_twoYear = median(base_rmb[month_Intervals <= 24 & flow_type == '4']),
      
      base_rmb_type5_median = median(base_rmb[flow_type == '5']),
      base_rmb_type5_median_sixMonth = median(base_rmb[month_Intervals <= 6 & flow_type == '5']),
      base_rmb_type5_median_oneYear = median(base_rmb[month_Intervals <= 12 & flow_type == '5']),
      base_rmb_type5_median_twoYear = median(base_rmb[month_Intervals <= 24 & flow_type == '5']),
      
      base_rmb_type1_mean = mean(base_rmb[flow_type == '1']),
      base_rmb_type1_mean_sixMonth = mean(base_rmb[month_Intervals <= 6 & flow_type == '1']),
      base_rmb_type1_mean_oneYear = mean(base_rmb[month_Intervals <= 12 & flow_type == '1']),
      base_rmb_type1_mean_twoYear = mean(base_rmb[month_Intervals <= 24 & flow_type == '1']),
      
      base_rmb_type2_mean = mean(base_rmb[flow_type == '2']),
      base_rmb_type2_mean_sixMonth = mean(base_rmb[month_Intervals <= 6 & flow_type == '2']),
      base_rmb_type2_mean_oneYear = mean(base_rmb[month_Intervals <= 12 & flow_type == '2']),
      base_rmb_type2_mean_twoYear = mean(base_rmb[month_Intervals <= 24 & flow_type == '2']),
      
      base_rmb_type3_mean = mean(base_rmb[flow_type == '3']),
      base_rmb_type3_mean_sixMonth = mean(base_rmb[month_Intervals <= 6 & flow_type == '3']),
      base_rmb_type3_mean_oneYear = mean(base_rmb[month_Intervals <= 12 & flow_type == '3']),
      base_rmb_type3_mean_twoYear = mean(base_rmb[month_Intervals <= 24 & flow_type == '3']),
      
      base_rmb_type4_mean = mean(base_rmb[flow_type == '4']),
      base_rmb_type4_mean_sixMonth = mean(base_rmb[month_Intervals <= 6 & flow_type == '4']),
      base_rmb_type4_mean_oneYear = mean(base_rmb[month_Intervals <= 12 & flow_type == '4']),
      base_rmb_type4_mean_twoYear = mean(base_rmb[month_Intervals <= 24 & flow_type == '4']),
      
      base_rmb_type5_mean = mean(base_rmb[flow_type == '5']),
      base_rmb_type5_mean_sixMonth = mean(base_rmb[month_Intervals <= 6 & flow_type == '5']),
      base_rmb_type5_mean_oneYear = mean(base_rmb[month_Intervals <= 12 & flow_type == '5']),
      base_rmb_type5_mean_twoYear = mean(base_rmb[month_Intervals <= 24 & flow_type == '5']),
      
      balance_rmb_type1_median = median(balance_rmb[flow_type == '1']),
      balance_rmb_type1_median_sixMonth = median(balance_rmb[month_Intervals <= 6 & flow_type == '1']),
      balance_rmb_type1_median_oneYear = median(balance_rmb[month_Intervals <= 12 & flow_type == '1']),
      balance_rmb_type1_median_twoYear = median(balance_rmb[month_Intervals <= 24 & flow_type == '1']),
      
      balance_rmb_type2_median = median(balance_rmb[flow_type == '2']),
      balance_rmb_type2_median_sixMonth = median(balance_rmb[month_Intervals <= 6 & flow_type == '2']),
      balance_rmb_type2_median_oneYear = median(balance_rmb[month_Intervals <= 12 & flow_type == '2']),
      balance_rmb_type2_median_twoYear = median(balance_rmb[month_Intervals <= 24 & flow_type == '2']),
      
      balance_rmb_type3_median = median(balance_rmb[flow_type == '3']),
      balance_rmb_type3_median_sixMonth = median(balance_rmb[month_Intervals <= 6 & flow_type == '3']),
      balance_rmb_type3_median_oneYear = median(balance_rmb[month_Intervals <= 12 & flow_type == '3']),
      balance_rmb_type3_median_twoYear = median(balance_rmb[month_Intervals <= 24 & flow_type == '3']),
      
      balance_rmb_type4_median = median(balance_rmb[flow_type == '4']),
      balance_rmb_type4_median_sixMonth = median(balance_rmb[month_Intervals <= 6 & flow_type == '4']),
      balance_rmb_type4_median_oneYear = median(balance_rmb[month_Intervals <= 12 & flow_type == '4']),
      balance_rmb_type4_median_twoYear = median(balance_rmb[month_Intervals <= 24 & flow_type == '4']),
      
      balance_rmb_type5_median = median(balance_rmb[flow_type == '5']),
      balance_rmb_type5_median_sixMonth = median(balance_rmb[month_Intervals <= 6 & flow_type == '5']),
      balance_rmb_type5_median_oneYear = median(balance_rmb[month_Intervals <= 12 & flow_type == '5']),
      balance_rmb_type5_median_twoYear = median(balance_rmb[month_Intervals <= 24 & flow_type == '5']),
      
      balance_rmb_type1_mean = mean(balance_rmb[flow_type == '1']),
      balance_rmb_type1_mean_sixMonth = mean(balance_rmb[month_Intervals <= 6 & flow_type == '1']),
      balance_rmb_type1_mean_oneYear = mean(balance_rmb[month_Intervals <= 12 & flow_type == '1']),
      balance_rmb_type1_mean_twoYear = mean(balance_rmb[month_Intervals <= 24 & flow_type == '1']),
      
      balance_rmb_type2_mean = mean(balance_rmb[flow_type == '2']),
      balance_rmb_type2_mean_sixMonth = mean(balance_rmb[month_Intervals <= 6 & flow_type == '2']),
      balance_rmb_type2_mean_oneYear = mean(balance_rmb[month_Intervals <= 12 & flow_type == '2']),
      balance_rmb_type2_mean_twoYear = mean(balance_rmb[month_Intervals <= 24 & flow_type == '2']),
      
      balance_rmb_type3_mean = mean(balance_rmb[flow_type == '3']),
      balance_rmb_type3_mean_sixMonth = mean(balance_rmb[month_Intervals <= 6 & flow_type == '3']),
      balance_rmb_type3_mean_oneYear = mean(balance_rmb[month_Intervals <= 12 & flow_type == '3']),
      balance_rmb_type3_mean_twoYear = mean(balance_rmb[month_Intervals <= 24 & flow_type == '3']),
      
      balance_rmb_type4_mean = mean(balance_rmb[flow_type == '4']),
      balance_rmb_type4_mean_sixMonth = mean(balance_rmb[month_Intervals <= 6 & flow_type == '4']),
      balance_rmb_type4_mean_oneYear = mean(balance_rmb[month_Intervals <= 12 & flow_type == '4']),
      balance_rmb_type4_mean_twoYear = mean(balance_rmb[month_Intervals <= 24 & flow_type == '4']),
      
      balance_rmb_type5_mean = mean(balance_rmb[flow_type == '5']),
      balance_rmb_type5_mean_sixMonth = mean(balance_rmb[month_Intervals <= 6 & flow_type == '5']),
      balance_rmb_type5_mean_oneYear = mean(balance_rmb[month_Intervals <= 12 & flow_type == '5']),
      balance_rmb_type5_mean_twoYear = mean(balance_rmb[month_Intervals <= 24 & flow_type == '5']),
      
      
      com_rmb_type1_median = median(com_rmb[flow_type == '1']),
      com_rmb_type1_median_sixMonth = median(com_rmb[month_Intervals <= 6 & flow_type == '1']),
      com_rmb_type1_median_oneYear = median(com_rmb[month_Intervals <= 12 & flow_type == '1']),
      com_rmb_type1_median_twoYear = median(com_rmb[month_Intervals <= 24 & flow_type == '1']),
      
      com_rmb_type2_median = median(com_rmb[flow_type == '2']),
      com_rmb_type2_median_sixMonth = median(com_rmb[month_Intervals <= 6 & flow_type == '2']),
      com_rmb_type2_median_oneYear = median(com_rmb[month_Intervals <= 12 & flow_type == '2']),
      com_rmb_type2_median_twoYear = median(com_rmb[month_Intervals <= 24 & flow_type == '2']),
      
      com_rmb_type3_median = median(com_rmb[flow_type == '3']),
      com_rmb_type3_median_sixMonth = median(com_rmb[month_Intervals <= 6 & flow_type == '3']),
      com_rmb_type3_median_oneYear = median(com_rmb[month_Intervals <= 12 & flow_type == '3']),
      com_rmb_type3_median_twoYear = median(com_rmb[month_Intervals <= 24 & flow_type == '3']),
      
      com_rmb_type4_median = median(com_rmb[flow_type == '4']),
      com_rmb_type4_median_sixMonth = median(com_rmb[month_Intervals <= 6 & flow_type == '4']),
      com_rmb_type4_median_oneYear = median(com_rmb[month_Intervals <= 12 & flow_type == '4']),
      com_rmb_type4_median_twoYear = median(com_rmb[month_Intervals <= 24 & flow_type == '4']),
      
      com_rmb_type5_median = median(com_rmb[flow_type == '5']),
      com_rmb_type5_median_sixMonth = median(com_rmb[month_Intervals <= 6 & flow_type == '5']),
      com_rmb_type5_median_oneYear = median(com_rmb[month_Intervals <= 12 & flow_type == '5']),
      com_rmb_type5_median_twoYear = median(com_rmb[month_Intervals <= 24 & flow_type == '5']),
      
      com_rmb_type1_mean = mean(com_rmb[flow_type == '1']),
      com_rmb_type1_mean_sixMonth = mean(com_rmb[month_Intervals <= 6 & flow_type == '1']),
      com_rmb_type1_mean_oneYear = mean(com_rmb[month_Intervals <= 12 & flow_type == '1']),
      com_rmb_type1_mean_twoYear = mean(com_rmb[month_Intervals <= 24 & flow_type == '1']),
      
      com_rmb_type2_mean = mean(com_rmb[flow_type == '2']),
      com_rmb_type2_mean_sixMonth = mean(com_rmb[month_Intervals <= 6 & flow_type == '2']),
      com_rmb_type2_mean_oneYear = mean(com_rmb[month_Intervals <= 12 & flow_type == '2']),
      com_rmb_type2_mean_twoYear = mean(com_rmb[month_Intervals <= 24 & flow_type == '2']),
      
      com_rmb_type3_mean = mean(com_rmb[flow_type == '3']),
      com_rmb_type3_mean_sixMonth = mean(com_rmb[month_Intervals <= 6 & flow_type == '3']),
      com_rmb_type3_mean_oneYear = mean(com_rmb[month_Intervals <= 12 & flow_type == '3']),
      com_rmb_type3_mean_twoYear = mean(com_rmb[month_Intervals <= 24 & flow_type == '3']),
      
      com_rmb_type4_mean = mean(com_rmb[flow_type == '4']),
      com_rmb_type4_mean_sixMonth = mean(com_rmb[month_Intervals <= 6 & flow_type == '4']),
      com_rmb_type4_mean_oneYear = mean(com_rmb[month_Intervals <= 12 & flow_type == '4']),
      com_rmb_type4_mean_twoYear = mean(com_rmb[month_Intervals <= 24 & flow_type == '4']),
      
      com_rmb_type5_mean = mean(com_rmb[flow_type == '5']),
      com_rmb_type5_mean_sixMonth = mean(com_rmb[month_Intervals <= 6 & flow_type == '5']),
      com_rmb_type5_mean_oneYear = mean(com_rmb[month_Intervals <= 12 & flow_type == '5']),
      com_rmb_type5_mean_twoYear = mean(com_rmb[month_Intervals <= 24 & flow_type == '5']),
      
      com_rmb_type1_sum = sum(month_rmb[flow_type == '1']),
      com_rmb_type1_sum_sixMonth = sum(com_rmb[month_Intervals <= 6 & flow_type == '1']),
      com_rmb_type1_sum_oneYear = sum(com_rmb[month_Intervals <= 12 & flow_type == '1']),
      com_rmb_type1_sum_twoYear = sum(com_rmb[month_Intervals <= 24 & flow_type == '1']),
      
      com_rmb_type2_sum = sum(month_rmb[flow_type == '2']),
      com_rmb_type2_sum_sixMonth = sum(com_rmb[month_Intervals <= 6 & flow_type == '2']),
      com_rmb_type2_sum_oneYear = sum(com_rmb[month_Intervals <= 12 & flow_type == '2']),
      com_rmb_type2_sum_twoYear = sum(com_rmb[month_Intervals <= 24 & flow_type == '2']),
      
      com_rmb_type3_sum = sum(month_rmb[flow_type == '3']),
      com_rmb_type3_sum_sixMonth = sum(com_rmb[month_Intervals <= 6 & flow_type == '3']),
      com_rmb_type3_sum_oneYear = sum(com_rmb[month_Intervals <= 12 & flow_type == '3']),
      com_rmb_type3_sum_twoYear = sum(com_rmb[month_Intervals <= 24 & flow_type == '3']),
      
      com_rmb_type4_sum = sum(month_rmb[flow_type == '4']),
      com_rmb_type4_sum_sixMonth = sum(com_rmb[month_Intervals <= 6 & flow_type == '4']),
      com_rmb_type4_sum_oneYear = sum(com_rmb[month_Intervals <= 12 & flow_type == '4']),
      com_rmb_type4_sum_twoYear = sum(com_rmb[month_Intervals <= 24 & flow_type == '4']),
      
      com_rmb_type5_sum = sum(month_rmb[flow_type == '5']),
      com_rmb_type5_sum_sixMonth = sum(com_rmb[month_Intervals <= 6 & flow_type == '5']),
      com_rmb_type5_sum_oneYear = sum(com_rmb[month_Intervals <= 12 & flow_type == '5']),
      com_rmb_type5_sum_twoYear = sum(com_rmb[month_Intervals <= 24 & flow_type == '5']),
      
      com_rmb_sum = sum(month_rmb),
      com_rmb_sum_sixMonth = sum(com_rmb[month_Intervals <= 6]),
      com_rmb_sum_oneYear = sum(com_rmb[month_Intervals <= 12]),
      com_rmb_sum_twoYear = sum(com_rmb[month_Intervals <= 24]),
      
      per_rmb_type1_median = median(per_rmb[flow_type == '1']),
      per_rmb_median_type1_sixMonth = median(per_rmb[month_Intervals <= 6 & flow_type == '1']),
      per_rmb_median_type1_oneYear = median(per_rmb[month_Intervals <= 12 & flow_type == '1']),
      per_rmb_median_type1_twoYear = median(per_rmb[month_Intervals <= 24 & flow_type == '1']),
      
      per_rmb_type2_median = median(per_rmb[flow_type == '2']),
      per_rmb_median_type2_sixMonth = median(per_rmb[month_Intervals <= 6 & flow_type == '2']),
      per_rmb_median_type2_oneYear = median(per_rmb[month_Intervals <= 12 & flow_type == '2']),
      per_rmb_median_type2_twoYear = median(per_rmb[month_Intervals <= 24 & flow_type == '2']),
      
      per_rmb_type3_median = median(per_rmb[flow_type == '3']),
      per_rmb_median_type3_sixMonth = median(per_rmb[month_Intervals <= 6 & flow_type == '3']),
      per_rmb_median_type3_oneYear = median(per_rmb[month_Intervals <= 12 & flow_type == '3']),
      per_rmb_median_type3_twoYear = median(per_rmb[month_Intervals <= 24 & flow_type == '3']),
      
      per_rmb_type4_median = median(per_rmb[flow_type == '4']),
      per_rmb_median_type4_sixMonth = median(per_rmb[month_Intervals <= 6 & flow_type == '4']),
      per_rmb_median_type4_oneYear = median(per_rmb[month_Intervals <= 12 & flow_type == '4']),
      per_rmb_median_type4_twoYear = median(per_rmb[month_Intervals <= 24 & flow_type == '4']),
      
      per_rmb_type5_median = median(per_rmb[flow_type == '5']),
      per_rmb_type5_median_sixMonth = median(per_rmb[month_Intervals <= 6 & flow_type == '5']),
      per_rmb_type5_median_oneYear = median(per_rmb[month_Intervals <= 12 & flow_type == '5']),
      per_rmb_type5_median_twoYear = median(per_rmb[month_Intervals <= 24 & flow_type == '5']),
      
      per_rmb_type1_mean = mean(per_rmb[flow_type == '1']),
      per_rmb_mean_type1_sixMonth = mean(per_rmb[month_Intervals <= 6 & flow_type == '1']),
      per_rmb_mean_type1_oneYear = mean(per_rmb[month_Intervals <= 12 & flow_type == '1']),
      per_rmb_mean_type1_twoYear = mean(per_rmb[month_Intervals <= 24 & flow_type == '1']),
      
      per_rmb_type2_mean = mean(per_rmb[flow_type == '2']),
      per_rmb_mean_type2_sixMonth = mean(per_rmb[month_Intervals <= 6 & flow_type == '2']),
      per_rmb_mean_type2_oneYear = mean(per_rmb[month_Intervals <= 12 & flow_type == '2']),
      per_rmb_mean_type2_twoYear = mean(per_rmb[month_Intervals <= 24 & flow_type == '2']),
      
      per_rmb_type3_mean = mean(per_rmb[flow_type == '3']),
      per_rmb_mean_type3_sixMonth = mean(per_rmb[month_Intervals <= 6 & flow_type == '3']),
      per_rmb_mean_type3_oneYear = mean(per_rmb[month_Intervals <= 12 & flow_type == '3']),
      per_rmb_mean_type3_twoYear = mean(per_rmb[month_Intervals <= 24 & flow_type == '3']),
      
      per_rmb_type4_mean = mean(per_rmb[flow_type == '4']),
      per_rmb_mean_type4_sixMonth = mean(per_rmb[month_Intervals <= 6 & flow_type == '4']),
      per_rmb_mean_type4_oneYear = mean(per_rmb[month_Intervals <= 12 & flow_type == '4']),
      per_rmb_mean_type4_twoYear = mean(per_rmb[month_Intervals <= 24 & flow_type == '4']),
      
      per_rmb_type5_mean = mean(per_rmb[flow_type == '5']),
      per_rmb_type5_mean_sixMonth = mean(per_rmb[month_Intervals <= 6 & flow_type == '5']),
      per_rmb_type5_mean_oneYear = mean(per_rmb[month_Intervals <= 12 & flow_type == '5']),
      per_rmb_type5_mean_twoYear = mean(per_rmb[month_Intervals <= 24 & flow_type == '5']),
      
      per_rmb_type1_sum = sum(per_rmb[flow_type == '1']),
      per_rmb_type1_sum_sixMonth = sum(per_rmb[month_Intervals <= 6 & flow_type == '1']),
      per_rmb_type1_sum_oneYear = sum(per_rmb[month_Intervals <= 12 & flow_type == '1']),
      per_rmb_type1_sum_twoYear = sum(per_rmb[month_Intervals <= 24 & flow_type == '1']),
      
      per_rmb_type2_sum = sum(per_rmb[flow_type == '2']),
      per_rmb_type2_sum_sixMonth = sum(per_rmb[month_Intervals <= 6 & flow_type == '2']),
      per_rmb_type2_sum_oneYear = sum(per_rmb[month_Intervals <= 12 & flow_type == '2']),
      per_rmb_type2_sum_twoYear = sum(per_rmb[month_Intervals <= 24 & flow_type == '2']),
      
      per_rmb_type3_sum = sum(per_rmb[flow_type == '3']),
      per_rmb_type3_sum_sixMonth = sum(per_rmb[month_Intervals <= 6 & flow_type == '3']),
      per_rmb_type3_sum_oneYear = sum(per_rmb[month_Intervals <= 12 & flow_type == '3']),
      per_rmb_type3_sum_twoYear = sum(per_rmb[month_Intervals <= 24 & flow_type == '3']),
      
      per_rmb_type4_sum = sum(per_rmb[flow_type == '4']),
      per_rmb_type4_sum_sixMonth = sum(per_rmb[month_Intervals <= 6 & flow_type == '4']),
      per_rmb_type4_sum_oneYear = sum(per_rmb[month_Intervals <= 12 & flow_type == '4']),
      per_rmb_type4_sum_twoYear = sum(per_rmb[month_Intervals <= 24 & flow_type == '4']),
      
      per_rmb_type5_sum = sum(per_rmb[flow_type == '5']),
      per_rmb_type5_sum_sixMonth = sum(per_rmb[month_Intervals <= 6 & flow_type == '5']),
      per_rmb_type5_sum_oneYear = sum(per_rmb[month_Intervals <= 12 & flow_type == '5']),
      per_rmb_type5_sum_twoYear = sum(per_rmb[month_Intervals <= 24 & flow_type == '5']),
      
      per_rmb_sum = sum(per_rmb),
      per_rmb_sum_sixMonth = sum(per_rmb[month_Intervals <= 6]),
      per_rmb_sum_oneYear = sum(per_rmb[month_Intervals <= 12]),
      per_rmb_sum_twoYear = sum(per_rmb[month_Intervals <= 24]),
      
      month_rmb_type1_median = median(month_rmb[flow_type == '1']),
      month_rmb_type1_median_sixMonth = median(month_rmb[month_Intervals <= 6 & flow_type == '1']),
      month_rmb_type1_median_oneYear = median(month_rmb[month_Intervals <= 12 & flow_type == '1']),
      month_rmb_type1_median_twoYear = median(month_rmb[month_Intervals <= 24 & flow_type == '1']),
      
      month_rmb_type2_median = median(month_rmb[flow_type == '2']),
      month_rmb_type2_median_sixMonth = median(month_rmb[month_Intervals <= 6 & flow_type == '2']),
      month_rmb_type2_median_oneYear = median(month_rmb[month_Intervals <= 12 & flow_type == '2']),
      month_rmb_type2_median_twoYear = median(month_rmb[month_Intervals <= 24 & flow_type == '2']),
      
      month_rmb_type3_median = median(month_rmb[flow_type == '3']),
      month_rmb_type3_median_sixMonth = median(month_rmb[month_Intervals <= 6 & flow_type == '3']),
      month_rmb_type3_median_oneYear = median(month_rmb[month_Intervals <= 12 & flow_type == '3']),
      month_rmb_type3_median_twoYear = median(month_rmb[month_Intervals <= 24 & flow_type == '3']),
      
      month_rmb_type4_median = median(month_rmb[flow_type == '4']),
      month_rmb_type4_median_sixMonth = median(month_rmb[month_Intervals <= 6 & flow_type == '4']),
      month_rmb_type4_median_oneYear = median(month_rmb[month_Intervals <= 12 & flow_type == '4']),
      month_rmb_type4_median_twoYear = median(month_rmb[month_Intervals <= 24 & flow_type == '4']),
      
      month_rmb_type5_median = median(month_rmb[flow_type == '5']),
      month_rmb_type5_median_sixMonth = median(month_rmb[month_Intervals <= 6 & flow_type == '5']),
      month_rmb_type5_median_oneYear = median(month_rmb[month_Intervals <= 12 & flow_type == '5']),
      month_rmb_type5_median_twoYear = median(month_rmb[month_Intervals <= 24 & flow_type == '5']),
      
      month_rmb_type1_mean = mean(month_rmb[flow_type == '1']),
      month_rmb_type1_mean_sixMonth = mean(month_rmb[month_Intervals <= 6 & flow_type == '1']),
      month_rmb_type1_mean_oneYear = mean(month_rmb[month_Intervals <= 12 & flow_type == '1']),
      month_rmb_type1_mean_twoYear = mean(month_rmb[month_Intervals <= 24 & flow_type == '1']),
      
      month_rmb_type2_mean = mean(month_rmb[flow_type == '2']),
      month_rmb_type2_mean_sixMonth = mean(month_rmb[month_Intervals <= 6 & flow_type == '2']),
      month_rmb_type2_mean_oneYear = mean(month_rmb[month_Intervals <= 12 & flow_type == '2']),
      month_rmb_type2_mean_twoYear = mean(month_rmb[month_Intervals <= 24 & flow_type == '2']),
      
      month_rmb_type3_mean = mean(month_rmb[flow_type == '3']),
      month_rmb_type3_mean_sixMonth = mean(month_rmb[month_Intervals <= 6 & flow_type == '3']),
      month_rmb_type3_mean_oneYear = mean(month_rmb[month_Intervals <= 12 & flow_type == '3']),
      month_rmb_type3_mean_twoYear = mean(month_rmb[month_Intervals <= 24 & flow_type == '3']),
      
      month_rmb_type4_mean = mean(month_rmb[flow_type == '4']),
      month_rmb_type4_mean_sixMonth = mean(month_rmb[month_Intervals <= 6 & flow_type == '4']),
      month_rmb_type4_mean_oneYear = mean(month_rmb[month_Intervals <= 12 & flow_type == '4']),
      month_rmb_type4_mean_twoYear = mean(month_rmb[month_Intervals <= 24 & flow_type == '4']),
      
      month_rmb_type5_mean = mean(month_rmb[flow_type == '5']),
      month_rmb_type5_mean_sixMonth = mean(month_rmb[month_Intervals <= 6 & flow_type == '5']),
      month_rmb_type5_mean_oneYear = mean(month_rmb[month_Intervals <= 12 & flow_type == '5']),
      month_rmb_type5_mean_twoYear = mean(month_rmb[month_Intervals <= 24 & flow_type == '5']),
      
      month_rmb_type1_sum = sum(month_rmb[flow_type == '1']),
      month_rmb_type1_sum_sixMonth = sum(month_rmb[month_Intervals <= 6 & flow_type == '1']),
      month_rmb_type1_sum_oneYear = sum(month_rmb[month_Intervals <= 12 & flow_type == '1']),
      month_rmb_type1_sum_twoYear = sum(month_rmb[month_Intervals <= 24 & flow_type == '1']),
      
      month_rmb_type2_sum = sum(month_rmb[flow_type == '2']),
      month_rmb_type2_sum_sixMonth = sum(month_rmb[month_Intervals <= 6 & flow_type == '2']),
      month_rmb_type2_sum_oneYear = sum(month_rmb[month_Intervals <= 12 & flow_type == '2']),
      month_rmb_type2_sum_twoYear = sum(month_rmb[month_Intervals <= 24 & flow_type == '2']),
      
      month_rmb_type3_sum = sum(month_rmb[flow_type == '3']),
      month_rmb_type3_sum_sixMonth = sum(month_rmb[month_Intervals <= 6 & flow_type == '3']),
      month_rmb_type3_sum_oneYear = sum(month_rmb[month_Intervals <= 12 & flow_type == '3']),
      month_rmb_type3_sum_twoYear = sum(month_rmb[month_Intervals <= 24 & flow_type == '3']),
      
      month_rmb_type4_sum = sum(month_rmb[flow_type == '4']),
      month_rmb_type4_sum_sixMonth = sum(month_rmb[month_Intervals <= 6 & flow_type == '4']),
      month_rmb_type4_sum_oneYear = sum(month_rmb[month_Intervals <= 12 & flow_type == '4']),
      month_rmb_type4_sum_twoYear = sum(month_rmb[month_Intervals <= 24 & flow_type == '4']),
      
      month_rmb_type5_sum = sum(month_rmb[flow_type == '5']),
      month_rmb_type5_sum_sixMonth = sum(month_rmb[month_Intervals <= 6 & flow_type == '5']),
      month_rmb_type5_sum_oneYear = sum(month_rmb[month_Intervals <= 12 & flow_type == '5']),
      month_rmb_type5_sum_twoYear = sum(month_rmb[month_Intervals <= 24 & flow_type == '5']),
      
      month_rmb_sum = sum(month_rmb),
      month_rmb_sum_sixMonth = sum(month_rmb[month_Intervals <= 6]),
      month_rmb_sum_oneYear = sum(month_rmb[month_Intervals <= 12]),
      month_rmb_sum_twoYear = sum(month_rmb[month_Intervals <= 24]),
      
      com_per_ratio_type1_median = com_rmb_type1_median / (per_rmb_type1_median + 1),
      com_per_ratio_type2_median = com_rmb_type2_median / (per_rmb_type2_median + 1),
      com_per_ratio_type3_median = com_rmb_type3_median / (per_rmb_type3_median + 1),
      com_per_ratio_type4_median = com_rmb_type4_median / (per_rmb_type4_median + 1),
      com_per_ratio_type5_median = com_rmb_type5_median / (per_rmb_type5_median + 1),
      
      com_per_ratio_type1_mean = com_rmb_type1_mean / (per_rmb_type1_mean + 1),
      com_per_ratio_type2_mean = com_rmb_type2_mean / (per_rmb_type2_mean + 1),
      com_per_ratio_type3_mean = com_rmb_type3_mean / (per_rmb_type3_mean + 1),
      com_per_ratio_type4_mean = com_rmb_type4_mean / (per_rmb_type4_mean + 1),
      com_per_ratio_type5_mean = com_rmb_type5_mean / (per_rmb_type5_mean + 1),
      
      com_per_ratio_type1_sum = com_rmb_type1_sum / (per_rmb_type1_sum + 1),
      com_per_ratio_type2_sum = com_rmb_type2_sum / (per_rmb_type2_sum + 1),
      com_per_ratio_type3_sum = com_rmb_type3_sum / (per_rmb_type3_sum + 1),
      com_per_ratio_type4_sum = com_rmb_type4_sum / (per_rmb_type4_sum + 1),
      com_per_ratio_type5_sum = com_rmb_type5_sum / (per_rmb_type5_sum + 1),
      com_per_ratio_sum = com_rmb_sum / (per_rmb_sum + 1),
      
      
      month_com_ratio_type1_median = month_rmb_type1_median / (com_rmb_type1_median + 1),
      month_com_ratio_type2_median = month_rmb_type2_median / (com_rmb_type2_median + 1),
      month_com_ratio_type3_median = month_rmb_type3_median / (com_rmb_type3_median + 1),
      month_com_ratio_type4_median = month_rmb_type4_median / (com_rmb_type4_median + 1),
      month_com_ratio_type5_median = month_rmb_type5_median / (com_rmb_type5_median + 1),
      
      month_com_ratio_type1_mean = month_rmb_type1_mean / (com_rmb_type1_mean + 1),
      month_com_ratio_type2_mean = month_rmb_type2_mean / (com_rmb_type2_mean + 1),
      month_com_ratio_type3_mean = month_rmb_type3_mean / (com_rmb_type3_mean + 1),
      month_com_ratio_type4_mean = month_rmb_type4_mean / (com_rmb_type4_mean + 1),
      month_com_ratio_type5_mean = month_rmb_type5_mean / (com_rmb_type5_mean + 1),
      
      month_com_ratio_type1_sum = month_rmb_type1_sum / (com_rmb_type1_sum + 1),
      month_com_ratio_type2_sum = month_rmb_type2_sum / (com_rmb_type2_sum + 1),
      month_com_ratio_type3_sum = month_rmb_type3_sum / (com_rmb_type3_sum + 1),
      month_com_ratio_type4_sum = month_rmb_type4_sum / (com_rmb_type4_sum + 1),
      month_com_ratio_type5_sum = month_rmb_type5_sum / (com_rmb_type5_sum + 1),
      month_com_ratio_sum = month_rmb_sum / (com_rmb_sum + 1),
      
      base_per_ratio_type1_median = base_rmb_type1_median / (per_rmb_type1_median + 1),
      base_per_ratio_type2_median = base_rmb_type2_median / (per_rmb_type2_median + 1),
      base_per_ratio_type3_median = base_rmb_type3_median / (per_rmb_type3_median + 1),
      base_per_ratio_type4_median = base_rmb_type4_median / (per_rmb_type4_median + 1),
      base_per_ratio_type5_median = base_rmb_type5_median / (per_rmb_type5_median + 1),
      
      base_per_ratio_type1_mean = base_rmb_type1_mean / (per_rmb_type1_mean + 1),
      base_per_ratio_type2_mean = base_rmb_type2_mean / (per_rmb_type2_mean + 1),
      base_per_ratio_type3_mean = base_rmb_type3_mean / (per_rmb_type3_mean + 1),
      base_per_ratio_type4_mean = base_rmb_type4_mean / (per_rmb_type4_mean + 1),
      base_per_ratio_type5_mean = base_rmb_type5_mean / (per_rmb_type5_mean + 1),
      
      com_per_add_type1_median = com_rmb_type1_median + per_rmb_type1_median,
      com_per_add_type2_median = com_rmb_type2_median + per_rmb_type2_median,
      com_per_add_type3_median = com_rmb_type3_median + per_rmb_type3_median,
      com_per_add_type4_median = com_rmb_type4_median + per_rmb_type4_median,
      com_per_add_type5_median = com_rmb_type5_median + per_rmb_type5_median,
      
      com_per_add_type1_mean = com_rmb_type1_mean + per_rmb_type1_mean,
      com_per_add_type2_mean = com_rmb_type2_mean + per_rmb_type2_mean,
      com_per_add_type3_mean = com_rmb_type3_mean + per_rmb_type3_mean,
      com_per_add_type4_mean = com_rmb_type4_mean + per_rmb_type4_mean,
      com_per_add_type5_mean = com_rmb_type5_mean + per_rmb_type5_mean,
      
      com_per_add_type1_sum = com_rmb_type1_sum + per_rmb_type1_sum,
      com_per_add_type2_sum = com_rmb_type2_sum + per_rmb_type2_sum,
      com_per_add_type3_sum = com_rmb_type3_sum + per_rmb_type3_sum,
      com_per_add_type4_sum = com_rmb_type4_sum + per_rmb_type4_sum,
      com_per_add_type5_sum = com_rmb_type5_sum + per_rmb_type5_sum,
      com_per_add_sum = com_rmb_sum + per_rmb_sum
    )
  X_detail_features[is.na(X_detail_features)] <- 0
  X_detail_features <- X_detail_features %>%
    select(-appl_no)
  return(X_detail_features)
}

