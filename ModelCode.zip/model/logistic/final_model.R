#################
#Author:yunbin.jiang, EnglishName:joey
#Import:***
#Date:'18 April 2017'

#another way  call the GBM variables
#TrainIVdata <- train[colnames(train)%in%dfGbmSelectedVarsV01]


# correlation & colinear treatment/ caret
zeroVar=nearZeroVar(TrainIVdata, 99/1)
vars2RmLowVariance <- names(TrainIVdata)[zeroVar]
TrainIVdata1 <- TrainIVdata[, -zeroVar]
# correlation
corMatrix <- cor(TrainIVdata1)
varHighCorr <- findCorrelation(corMatrix, 0.9)
vars2RmHighCorr <- names(TrainIVdata1)[varHighCorr]
TrainIVdata2 <- TrainIVdata1[, -varHighCorr]
# collinearity
collinearInfo <- findLinearCombos(TrainIVdata2)
vars2RmCollinear <- names(TrainIVdata2)[collinearInfo$remove]
TrainIVdata3 <- TrainIVdata2[, -collinearInfo$remove]


model_data = TrainIVdata3[c('appl_no','objective',names(TrainIVdata3)[names(TrainIVdata3) %like% 'NV_'])]
model_data[model==-Inf] <- 0
model_data[model==Inf] <- 0


##logistic model
pre <-glm(target~.,data=model_data, family = "binomial")
#rondom_pre <-randomForest(target~.,data=model_data,ntree=100, proximity=TRUE)
#step()
backwards = step(fit)
summary(backwards)
#prediction
pred <- predict(pre,newdata = test)

##AUC
library(pROC)
modelroc <- roc(model_data$target,pred)
plot(modelroc, print.auc=TRUE, auc.polygon=TRUE, grid=c(0.1, 0.2),
     grid.col=c("green", "red"), max.auc.polygon=TRUE,
     auc.polygon.col="skyblue", print.thres=TRUE)


#KS
library(ROCR)
pred1 <- prediction(model_data$pred, model_data$target)
perf <- performance(pred1,"tpr","fpr")
max(attr(perf,'y.values')[[1]]-attr(perf,'x.values')[[1]])##KS
plot(perf)
performance(pred, 'auc')##AUC

