#Title :GBM select variables
#Author:yunbin.jiang, EnglishName:joey
#Import:***
#Date:'18 April 2017'

# gbm select vars
load("file/dfModelInputData.RData")
dfModelInputData <- dfModelInputData[dfModelInputData$flagSplit == 'train', ]


pubToolPath <- 'file'
source(sprintf('%s/msModelBaseSelection.R', pubToolPath))

require(ROCR)
require(gbm)
target <- 'targetDR'


# Useless variables
removeVar <- c('removed variables names')#
tempNamesX <- names(dfModelInputData)[names(dfModelInputData) %in% removeVar]
# cols <- lapply(dfModelInputData,class)
#unqiue(clos)
tempCharVars <- tempNamesX[lapply(dfModelInputData[, tempNamesX], class) == 'character']
tempFactVars <- tempNamesX[lapply(dfModelInputData[, tempNamesX], class) == 'factor']
tempDateVars <- tempNamesX[lapply(dfModelInputData[, tempNamesX], class) == 'Date']

# traslate the variables types
dfModelInputData$variables <- factor(dfModelInputData$variables, levels = levels)

groupNum <- 10
varNum <- length(tempNamesX)
varlable <- sample(rep(1:groupNum, length = varNum))# round 10

target <- 'targetDR'
# gbm parameter
distribution <- 'bernoulli'
thrdImp <- 0.99
n.trees=500 
shrinkage=0.01 
interaction.depth=3
bag.fraction = 0.5
n.minobsinnode = 30
train.fraction = 0.8
cv.folds = 5
keep.data=TRUE
verbose=TRUE

detailCheck = TRUE

sink('file/varselectiongbmV01.txt')###
for(i in 1:groupNum){
  tempNames <- tempNamesX[varlable == i]
  myFormula <- paste0(target,'~.')
  inputData <- dfModelInputData[, c(target, tempNames)]
  t1 <- proc.time()
  dfModelResult <- msModelVarSelGbm( as.formula(myFormula)
                                     ,distribution = distribution
                                     ,data = inputData
                                     ,n.trees = n.trees
                                     ,shrinkage = shrinkage
                                     ,interaction.depth = interaction.depth
                                     ,bag.fraction = bag.fraction
                                     ,train.fraction = train.fraction
                                     ,n.minobsinnode = n.minobsinnode
                                     ,cv.folds = cv.folds
                                     ,keep.data = keep.data
                                     ,verbose = verbose
                                     ,thrdImp = thrdImp
                                     ,detailCheck = detailCheck
  )
  cat('iter ', i ,' time cost: ', proc.time() - t1, '\n')
  
  if(i == 1) dfGbmSelectedVars <- data.frame()
  dfGbmSelectedVars <- rbind(dfGbmSelectedVars, dfModelResult, make.row.names = FALSE)
  #if(i == 1) dfResult <- list()
  #dfResult[[i]] <- dfModelResult
}

dev.off()

dfGbmSelectedVarsV01 <- dfGbmSelectedVars

save(dfGbmSelectedVarsV01, file = 'file/dfGbmSelectedVarsV01.RData', compress = TRUE)
write.csv(dfGbmSelectedVarsV01, file = 'file/dfGbmSelectedVarsV01.csv',col.names = TRUE, row.names = TRUE, sep = ',') 







