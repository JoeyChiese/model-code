#Title:Data handle
#Author:yunbin.jiang, EnglishName:joey
#Import:Hmisc
#Date:'18 April 2017'

## Sub-box discretization
binOrdinal <- function(analysisObject, n){
  for(i in colnames(analysisObject)){
    
    if( nrow(unique(analysisObject[i])) >= 10){
      
      # cut the normal data section    
      dataNormal <- analysisObject[i][analysisObject[i] < 999999971]
      cntTotNormal <- length(dataNormal) #  normal data  
      cntNormal <- ceiling(cntTotNormal / n)   # min number of groups for each normal value
      cutLcdvlNormal <- cut2(dataNormal,  m = cntNormal)   #cut the normal values
      
      cutLcdvlNormal <- as.character(cutLcdvlNormal)     
      analysisObject[i][analysisObject[i] < 999999971] <- as.character(analysisObject[i][analysisObject[i] < 999999971])
      analysisObject[i][analysisObject[i] < 999999971] <- cutLcdvlNormal
      cat(i)   
      
    }}
  return(analysisObject)
}


#woe and iv
ivFun <- function(iv_data){
iv <- c()
woe_l <- list()
woe_b <- list()
for(i in 1:ncol(iv_data)) {
  tmp_tb <- table(iv_data[,i],iv_data[,1]) 
  ##if(nrow(tmp_tb)==1){next} #处理只有一个分组的情况，直接进入下一次循环
  tmp_tb[is.na(tmp_tb) | tmp_tb==0] <- 1 
  prop_tb <- prop.table(tmp_tb,2)
  woe_l[[i]] <- log(prop_tb[,2]/prop_tb[,1]) #woe值
  woe_b[[i]] <- prop_tb[,2]-prop_tb[,1]
  iv[i] <- woe_l[[i]]%*% woe_b[[i]] #iv值
  #将woe_l和iv值的名称保留下来,便于后面计算
  names(woe_l)[i]<- colnames(iv_data)[i]
  names(iv)[i] <- colnames(iv_data)[i]  
  cat(i)
}
}



descriptive_data <- function(train){
  temp.train=matrix(0,nrow =ncol(train), ncol=13)
  colnames(temp.train)[1:13] <- c("sum","mean","median","max","min","range","variance","std","skewness","kurtosis")
for(i in 1:ncol(train)){
  Iv <- iv[i]
  Mean <- mean(train)
  Median <- median(train)
  Modes <- train[which.max(table(train))]#众数
  numMiss <- nrow(data)-length(train)#缺失值
  Samples <- nrow(data)
  Miss_rate <- numMiss/nrow(data)
  Sd <- sd(train)
  Var <- var(train)                    
  summary_min <- as.matrix(summary(train))[1]
  summary_max <- as.matrix(summary(train))[6]
  skew <- skewness(train)
  kurto <- kurtosis(train)
  temp.train[i,] <- cbind(Iv, numMiss,Samples, Miss_rate,Mean,Median,Modes,Sd,Var,summary_min,summary_max,skew,kurto)
}
}



woe.replace = function(df, ivout,chrname) {
  df = cbind(df, tmpname = NA)
  ncol = ncol(df)
  col_id = ivout$col_id
  df[, ncol][df[, col_id] >= ivout$bands[1] & df[, col_id] <= 
               ivout$bands[2]] = ivout$ivtable[13][1,]
  
  dim = length(ivout$bands)-1
  for (i in 2:dim) {
    df[, ncol][df[, col_id] > ivout$bands[i] & df[, col_id] <= 
                 ivout$bands[i+1]] = ivout$ivtable[13][i,]
  }
  df[, ncol][is.na(df[, col_id])] = ivout$ivtable[13][dim+1,]
  names(df)[names(df) == "tmpname"] =  chrname 
  return(df)
}



factor.woe.replace = function(df, ivout,chrname) {
  df = cbind(df, tmpname = NA)
  ncol = ncol(df)
  col_id = ivout$col_id
  dim = length(ivout$cuts)
  for (i in 1:dim) {
    df[, ncol][df[, col_id] == ivout$cuts[i]] = ivout$ivtable[13][i,]
  }
  df[, ncol][is.na(df[, col_id])] = ivout$ivtable[13][dim+1,]
  names(df)[names(df) == "tmpname"] =  chrname 
  return(df)
}
