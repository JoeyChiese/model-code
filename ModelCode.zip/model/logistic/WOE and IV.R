#Title:WOE and IV
#Author:yunbin.jiang, EnglishName:joey
#Import:***
#Date:'18 April 2017'
##loading packages
library(Rcpp)
library(lattice)
library(MASS)
library(EnvStats)
library(fBasics) 
library(timeDate)
library(timeSeries)
library(ggplot2)
library(Hmisc)
library(gridExtra)
library(smbinning)
library(randomForest)
library(h2o)
# loading the data
train <- load("file")
test <- load("file")

#types
cols <- unlist(lapply(train,class))
unique(cols)
names(cols[cols=="numeric"])
names(cols[cols=="factor"])
#names(cols[cols=="Date"])

# Missing value handling
for (i in 1:ncol(train)) {
  if (class(train[, i]) == "numeric"|class(train[, i])== "integer") {
    train[, i][is.na(train[, i])] <- 999999988
    
  } else {
    train[, i][is.na(train[, i])] <- "UNKNOWN"
    
  }
}

#1---continuous variables
options(scipen = 20)
Traindata_num <- train[,cols=="numeric"|cols=="integer"]

#del null、NA variables
rm_num1 <- unlist(lapply(Traindata_num, function(x){return(length(x[x > 999999971]))}))
Traindata_nm_Temp <- Traindata_num[,-which(rm_num1 == nrow(Traindata_num))]

source("file/data handingFun.R")
#discretization 
lisan_data <- binOrdinal(Traindata_nm_Temp, 10)
iv_data <- lisan_data
## save(iv_data,file = "file/lisan_data.RData")

#iv data
iv <- ivFun(iv_data)
iv_names <- names(sort(iv,decreasing = TRUE))
TrainIVdata <- cbind(train[,cols=="factor"],Traindata_nm_Temp[,iv_names])

# describle selected model variables 
for(i in 1:ncol(TrainIVdata)){
  Traindata_des <- descriptive_data(TrainIVdata) 
}
write.csv(Traindata_des, file = "file/describe.csv",sep = ",",row.names =TRUE,fileEncoding ="UTF-8")


# woe replace
re_list = list()
for(i in 2:ncol(TrainIVdata)){
  if(is.numeric(TrainIVdata[[i]])){
    result = smbinning(TrainIVdata,'objective',names(TrainIVdata[i]))
    re_list[[i]] = result
    if(is.list(result)){
      if(result$iv >= 0.02){
        print(result$iv)
        TrainIVdata = woe.replace(TrainIVdata,result,paste("NV_", names(TrainIVdata[i]),sep = ''))
      }
    }
    
  }else{
    result = smbinning.factor(TrainIVdata,'objective',names(TrainIVdata[i]))
    re_list[[i]] = result
    if(is.list(result)){
      if(result$iv > 0.02){
        print(names(TrainIVdata[i]))
        TrainIVdata = factor.woe.replace(TrainIVdata,result,paste("NV_", names(TrainIVdata[i]),sep = ''))
      }
    }
  }
}

